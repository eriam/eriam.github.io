// load dependencies
require("./code/load")("code/journal.js", "code/chapter/04_data.js");

for (let evenement of evenementsJournal(JOURNAL)) {
  let correlation = phi(tableauPour(evenement, JOURNAL));
  if (correlation > 0.1 || correlation < -0.1) {
    console.log(evenement + ":", correlation);
  }
}
// → brossé dents:  -0.3805211953
// → travail:       -0.1371988681
// → lire:           0.1106828054
